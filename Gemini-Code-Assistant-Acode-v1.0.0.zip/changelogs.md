# 1.0.0

- Initial release.
- Gemini streaming chat.
- Active-file and selection context.
- Editor insert/replace actions.
- File and image attachments.
- Voice input when supported.
- Model/settings controls.
- Local encrypted API-key storage through Acode plugin context.
