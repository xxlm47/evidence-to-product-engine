const PLUGIN_ID = "com.xxlm47.gemini-code-assistant";
const APP_ID = "xxlm47-gemini-code-assistant";
const DEFAULT_MODEL = "gemini-2.5-flash";
const DEFAULT_MAX_TOKENS = 4096;
const DEFAULT_SYSTEM = `You are Gemini Code Assistant inside the Acode editor. Be accurate, practical, and concise. When the user provides code, preserve its intent and existing style unless asked otherwise. Prefer complete, directly usable code. When proposing a change, explain the important reason briefly.`;

class GeminiCodeAssistant {
  constructor() {
    this.ctx = null;
    this.sidebar = null;
    this.container = null;
    this.commands = null;
    this.settings = null;
    this.history = [];
    this.currentResponse = "";
    this.abortController = null;
    this.model = DEFAULT_MODEL;
    this.systemPrompt = DEFAULT_SYSTEM;
    this.maxTokens = DEFAULT_MAX_TOKENS;
    this.temperature = 0.2;
    this.attachActive = true;
    this.lastSelection = "";
    this.imageParts = [];
    this.fileParts = [];
    this.recognition = null;
    this.initialized = false;
  }

  async init(_page, _cacheFile, _cacheFileUrl, _firstInit, ctx) {
    this.ctx = ctx;
    this.settings = acode.require("settings");
    this.commands = acode.require("commands");
    this.loadPrefs();
    this.registerCommands();
    this.registerSidebar();
    this.initialized = true;
  }

  loadPrefs() {
    const value = this.settings?.value?.[PLUGIN_ID] || {};
    this.model = value.model || DEFAULT_MODEL;
    this.systemPrompt = value.systemPrompt || DEFAULT_SYSTEM;
    this.maxTokens = Number(value.maxTokens || DEFAULT_MAX_TOKENS);
    this.temperature = Number(value.temperature ?? 0.2);
    this.attachActive = value.attachActive !== false;
  }

  savePref(key, value) {
    if (!this.settings) return;
    if (!this.settings.value[PLUGIN_ID]) this.settings.value[PLUGIN_ID] = {};
    this.settings.value[PLUGIN_ID][key] = value;
  }

  registerCommands() {
    const add = (name, description, exec) => {
      try { this.commands.addCommand({ name, description, exec }); } catch (_) {}
    };
    add("gemini-code-assistant", "Open Gemini Code Assistant", () => this.openSidebar());
    add("gemini-ask-selection", "Ask Gemini about selected code", () => this.askSelection());
    add("gemini-fix-selection", "Fix selected code with Gemini", () => this.runAction("Fix this code. Return the corrected code and a short explanation."));
    add("gemini-explain-selection", "Explain selected code with Gemini", () => this.runAction("Explain this code clearly. Focus on behavior, important details, bugs, and risks."));
    add("gemini-refactor-selection", "Refactor selected code with Gemini", () => this.runAction("Refactor this code for clarity, maintainability, and correctness. Return the complete replacement code."));
    add("gemini-review-file", "Review the active file with Gemini", () => this.reviewActiveFile());
  }

  registerSidebar() {
    this.sidebar = acode.require("sidebarApps");
    this.sidebar.add("icon-brain", APP_ID, "Gemini AI", (container) => {
      this.container = container;
      this.renderShell();
    }, true, () => {
      this.container = this.sidebar.get(APP_ID);
      this.renderShell();
    });
  }

  renderShell() {
    if (!this.container) return;
    this.container.innerHTML = `
      <style>${this.css()}</style>
      <div class="gca">
        <div class="gca-head">
          <div><strong>Gemini AI</strong><small id="gca-status">Ready</small></div>
          <div class="gca-head-actions">
            <button id="gca-new" title="New chat">＋</button>
            <button id="gca-settings" title="Settings">⚙</button>
          </div>
        </div>
        <div id="gca-chat" class="gca-chat scroll"></div>
        <div id="gca-attachments" class="gca-attachments"></div>
        <div class="gca-actions">
          <button data-action="file">📎</button>
          <button data-action="image">🖼</button>
          <button data-action="voice">🎙</button>
          <button data-action="context">${this.attachActive ? "📄" : "📄̸"}</button>
          <select id="gca-model" title="Model"></select>
        </div>
        <textarea id="gca-input" placeholder="Ask Gemini…" rows="3"></textarea>
        <div class="gca-sendrow">
          <span id="gca-context-label">${this.contextSummary()}</span>
          <button id="gca-stop" class="hidden">Stop</button>
          <button id="gca-send">Send</button>
        </div>
      </div>
    `;
    this.bindUI();
    this.populateModels();
    this.renderHistory();
  }

  css() {
    return `
      .gca{height:100%;display:flex;flex-direction:column;box-sizing:border-box;font-family:inherit;color:var(--primary-text-color,#eee);background:var(--primary-color,#222);font-size:14px}
      .gca *{box-sizing:border-box}.gca button,.gca select,.gca textarea{font:inherit}
      .gca-head{display:flex;justify-content:space-between;align-items:center;padding:10px 10px 8px;border-bottom:1px solid rgba(255,255,255,.12)}
      .gca-head strong{display:block;font-size:16px}.gca-head small{display:block;opacity:.55;margin-top:2px}.gca-head-actions{display:flex;gap:5px}.gca button{border:0;border-radius:7px;background:rgba(255,255,255,.08);color:inherit;padding:7px 9px}.gca button:active{background:rgba(255,255,255,.18)}
      .gca-chat{flex:1;min-height:0;padding:10px}.gca-msg{margin:0 0 12px}.gca-role{font-size:11px;text-transform:uppercase;opacity:.5;margin-bottom:4px}.gca-bubble{background:rgba(255,255,255,.06);border-radius:9px;padding:9px;line-height:1.45;overflow-wrap:anywhere}.gca-user .gca-bubble{background:rgba(70,130,255,.15)}
      .gca-code{position:relative;margin:8px 0;border-radius:7px;background:#111;overflow:auto}.gca-code pre{margin:0;padding:10px;white-space:pre;overflow:auto}.gca-copy{position:absolute;right:5px;top:5px;font-size:11px;padding:4px 6px}.gca-attachments{max-height:90px;overflow:auto;padding:0 8px}.gca-chip{display:inline-flex;align-items:center;gap:5px;margin:3px;padding:5px 7px;border-radius:99px;background:rgba(255,255,255,.08);font-size:11px}.gca-actions{display:flex;gap:5px;padding:7px 8px 5px;align-items:center}.gca-actions button{padding:6px}.gca-actions select{flex:1;min-width:0;background:rgba(255,255,255,.08);border:0;color:inherit;border-radius:7px;padding:6px}.gca textarea{width:calc(100% - 16px);margin:0 8px;resize:vertical;min-height:52px;max-height:180px;border:1px solid rgba(255,255,255,.13);background:rgba(0,0,0,.18);color:inherit;border-radius:8px;padding:8px;outline:none}.gca-sendrow{display:flex;align-items:center;gap:7px;padding:6px 8px 8px}.gca-sendrow #gca-context-label{flex:1;opacity:.5;font-size:10px;white-space:nowrap;overflow:hidden;text-overflow:ellipsis}.gca-send{background:var(--accent-color,#3f8cff)!important;color:#fff!important}.hidden{display:none!important}.gca-error{border-left:3px solid #e55}.gca-system{opacity:.7;font-size:12px}.gca-link{color:#76a9ff}.gca img{max-width:100%;border-radius:6px}.gca .scroll{overflow-y:auto}.gca .muted{opacity:.55}.gca-settings-panel{padding:10px}.gca-settings-panel label{display:block;margin:10px 0 4px;font-size:12px;opacity:.7}.gca-settings-panel input,.gca-settings-panel textarea,.gca-settings-panel select{width:100%;background:rgba(0,0,0,.2);color:inherit;border:1px solid rgba(255,255,255,.15);border-radius:7px;padding:8px}.gca-settings-panel textarea{min-height:120px}.gca-row{display:flex;gap:7px}.gca-row>*{flex:1}
    `;
  }

  bindUI() {
    const q = (id) => this.container.querySelector(id);
    q("#gca-send").onclick = () => this.send();
    q("#gca-stop").onclick = () => this.stop();
    q("#gca-new").onclick = () => this.newChat();
    q("#gca-settings").onclick = () => this.showSettings();
    q("#gca-input").addEventListener("keydown", (e) => {
      if (e.key === "Enter" && !e.shiftKey) { e.preventDefault(); this.send(); }
    });
    this.container.querySelectorAll("[data-action]").forEach(btn => btn.onclick = () => {
      const a = btn.dataset.action;
      if (a === "file") this.pickFile();
      if (a === "image") this.pickImage();
      if (a === "voice") this.toggleVoice();
      if (a === "context") { this.attachActive = !this.attachActive; this.savePref("attachActive", this.attachActive); this.renderShell(); }
    });
  }

  async populateModels() {
    const select = this.container?.querySelector("#gca-model");
    if (!select) return;
    const key = await this.getKey();
    const fallback = ["gemini-2.5-flash", "gemini-2.5-pro", "gemini-2.0-flash"];
    const names = new Set(fallback);
    if (key) {
      try {
        const res = await fetch(`https://generativelanguage.googleapis.com/v1beta/models?key=${encodeURIComponent(key)}`);
        if (res.ok) {
          const data = await res.json();
          for (const m of data.models || []) {
            const n = String(m.name || "").replace(/^models\//, "");
            const methods = m.supportedGenerationMethods || [];
            if (n && methods.includes("generateContent")) names.add(n);
          }
        }
      } catch (_) {}
    }
    select.innerHTML = [...names].map(n => `<option value="${this.esc(n)}">${this.esc(n)}</option>`).join("");
    select.value = [...names].includes(this.model) ? this.model : [...names][0];
    select.onchange = () => { this.model = select.value; this.savePref("model", this.model); };
  }

  contextSummary() {
    const parts = [];
    if (this.attachActive && this.getSelection()) parts.push("selection");
    if (this.attachActive && this.getActiveFileText()) parts.push("active file");
    if (this.fileParts.length) parts.push(`${this.fileParts.length} file${this.fileParts.length > 1 ? "s" : ""}`);
    if (this.imageParts.length) parts.push(`${this.imageParts.length} image${this.imageParts.length > 1 ? "s" : ""}`);
    return parts.length ? parts.join(" + ") : "No code context";
  }

  getEditor() { return window.editorManager?.editor || window.editor; }

  getSelection() {
    const e = this.getEditor();
    if (!e) return "";
    try {
      if (window.editorManager?.isCodeMirror && e.state?.selection?.main) {
        const r = e.state.selection.main;
        if (r.from !== r.to) return e.state.sliceDoc(r.from, r.to);
      }
      if (typeof e.getCopyText === "function") return e.getCopyText() || "";
      if (e.selection?.getRange && e.session) {
        const range = e.selection.getRange();
        if (range && !range.isEmpty()) return e.session.getTextRange(range);
      }
    } catch (_) {}
    return "";
  }

  getActiveFileText() {
    const e = this.getEditor();
    if (!e) return "";
    try {
      if (window.editorManager?.isCodeMirror && e.state?.doc) return e.state.doc.toString();
      if (typeof e.getValue === "function") return e.getValue();
    } catch (_) {}
    return "";
  }

  getActiveFilename() {
    return window.editorManager?.activeFile?.filename || window.editorManager?.activeFile?.name || "active-file";
  }

  replaceSelection(text) {
    const e = this.getEditor();
    if (!e) return false;
    try {
      if (window.editorManager?.isCodeMirror && e.state?.selection?.main) {
        const r = e.state.selection.main;
        e.dispatch({ changes: { from: r.from, to: r.to, insert: text } });
        return true;
      }
      if (typeof e.insert === "function") { e.insert(text); return true; }
    } catch (_) {}
    return false;
  }

  insertText(text) {
    const e = this.getEditor();
    if (!e) return false;
    try {
      if (window.editorManager?.isCodeMirror && e.state?.selection?.main) {
        const r = e.state.selection.main;
        e.dispatch({ changes: { from: r.from, to: r.to, insert: text } });
        return true;
      }
      if (typeof e.insert === "function") { e.insert(text); return true; }
    } catch (_) {}
    return false;
  }

  async runAction(instruction) {
    this.openSidebar();
    const code = this.getSelection() || this.getActiveFileText();
    if (!code) return this.setStatus("Select code or open a file first.", true);
    const input = this.container?.querySelector("#gca-input");
    if (input) input.value = instruction;
    await this.send();
  }

  async askSelection() {
    const code = this.getSelection();
    if (!code) return this.openSidebar();
    this.openSidebar();
    const input = this.container?.querySelector("#gca-input");
    if (input) input.value = "What does this code do? Point out bugs, risks, and useful improvements.";
    await this.send();
  }

  async reviewActiveFile() {
    const code = this.getActiveFileText();
    if (!code) return this.openSidebar();
    this.openSidebar();
    const input = this.container?.querySelector("#gca-input");
    if (input) input.value = "Review this entire file. Identify bugs, security issues, performance problems, maintainability problems, and concrete improvements.";
    await this.send();
  }

  openSidebar() {
    try { this.sidebar?.get(APP_ID)?.closest?.("*"); } catch (_) {}
    try { this.sidebar?.get(APP_ID)?.click?.(); } catch (_) {}
  }

  async getKey() {
    if (this.ctx?.getSecret) return await this.ctx.getSecret("gemini_api_key", "");
    return "";
  }

  async send() {
    const input = this.container?.querySelector("#gca-input");
    const prompt = input?.value?.trim();
    if (!prompt && !this.fileParts.length && !this.imageParts.length) return;
    const key = await this.getKey();
    if (!key) return this.setStatus("Add your Gemini API key in Settings → Plugins → Gemini Code Assistant.", true);

    const userParts = [];
    if (prompt) userParts.push({ text: prompt });
    if (this.attachActive) {
      const selection = this.getSelection();
      const file = this.getActiveFileText();
      if (selection) userParts.push({ text: `\nSelected code (${this.getActiveFilename()}):\n\`\`\`\n${selection}\n\`\`\`` });
      else if (file) userParts.push({ text: `\nActive file (${this.getActiveFilename()}):\n\`\`\`\n${file}\n\`\`\`` });
    }
    for (const p of this.fileParts) userParts.push(p);
    for (const p of this.imageParts) userParts.push(p);

    const historyContents = this.history.slice(-12).map(m => ({ role: m.role, parts: m.parts }));
    const contents = [...historyContents, { role: "user", parts: userParts }];
    this.history.push({ role: "user", parts: userParts });
    this.renderHistory();
    if (input) input.value = "";
    this.setStatus("Thinking…");
    this.setBusy(true);

    const assistantIndex = this.history.length;
    this.history.push({ role: "model", parts: [{ text: "" }] });
    this.currentResponse = "";
    this.renderHistory();

    try {
      const response = await this.streamGenerate(key, contents, (chunk) => {
        this.currentResponse += chunk;
        this.history[assistantIndex].parts[0].text = this.currentResponse;
        this.renderHistory(true);
      });
      if (!response && !this.currentResponse) throw new Error("Gemini returned an empty response.");
      this.setStatus("Ready");
    } catch (err) {
      this.history[assistantIndex].parts[0].text = `Error: ${err.message || err}`;
      this.renderHistory(true, true);
      this.setStatus("Request failed", true);
    } finally {
      this.setBusy(false);
      this.fileParts = [];
      this.imageParts = [];
      this.renderAttachments();
    }
  }

  async streamGenerate(key, contents, onChunk) {
    this.abortController = new AbortController();
    const url = `https://generativelanguage.googleapis.com/v1beta/models/${encodeURIComponent(this.model)}:streamGenerateContent?alt=sse&key=${encodeURIComponent(key)}`;
    const body = {
      systemInstruction: { parts: [{ text: this.systemPrompt }] },
      contents,
      generationConfig: { maxOutputTokens: this.maxTokens, temperature: this.temperature }
    };
    const res = await fetch(url, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(body),
      signal: this.abortController.signal
    });
    if (!res.ok) {
      let detail = `${res.status} ${res.statusText}`;
      try { const j = await res.json(); detail = j.error?.message || detail; } catch (_) {}
      throw new Error(detail);
    }
    if (!res.body) {
      const data = await res.json();
      const text = this.extractText(data);
      if (text) onChunk(text);
      return text;
    }
    const reader = res.body.getReader();
    const decoder = new TextDecoder();
    let buffer = "";
    let total = "";
    while (true) {
      const { value, done } = await reader.read();
      if (done) break;
      buffer += decoder.decode(value, { stream: true });
      const lines = buffer.split(/\r?\n/);
      buffer = lines.pop() || "";
      for (const line of lines) {
        if (!line.startsWith("data:")) continue;
        const raw = line.slice(5).trim();
        if (!raw || raw === "[DONE]") continue;
        try {
          const json = JSON.parse(raw);
          const text = this.extractText(json);
          if (text) { total += text; onChunk(text); }
        } catch (_) {}
      }
    }
    return total;
  }

  extractText(data) {
    if (!data) return "";
    if (Array.isArray(data.candidates)) {
      return data.candidates.flatMap(c => c.content?.parts || []).map(p => p.text || "").join("");
    }
    return data.text || "";
  }

  renderHistory(scrolling = false, error = false) {
    const chat = this.container?.querySelector("#gca-chat");
    if (!chat) return;
    chat.innerHTML = this.history.map((m, i) => {
      const text = m.parts?.map(p => p.text || "").join("\n") || "";
      const role = m.role === "user" ? "You" : "Gemini";
      return `<div class="gca-msg ${m.role === "user" ? "gca-user" : "gca-model"}"><div class="gca-role">${role}</div><div class="gca-bubble ${error && i === this.history.length - 1 ? "gca-error" : ""}">${this.renderMarkdown(text, i)}</div></div>`;
    }).join("");
    chat.querySelectorAll(".gca-copy").forEach(btn => btn.onclick = () => navigator.clipboard?.writeText(btn.dataset.code || ""));
    chat.querySelectorAll(".gca-insert").forEach(btn => btn.onclick = () => this.insertText(btn.dataset.code || ""));
    if (scrolling || this.history.length) chat.scrollTop = chat.scrollHeight;
  }

  renderMarkdown(text, msgIndex) {
    let out = this.esc(text);
    out = out.replace(/```([\w.+-]*)\n([\s\S]*?)```/g, (_m, lang, code) => {
      const raw = this.unesc(code).replace(/^\n|\n$/g, "");
      return `<div class="gca-code"><button class="gca-copy" data-code="${this.attr(raw)}">Copy</button><pre><code>${this.esc(raw)}</code></pre><button class="gca-insert" data-code="${this.attr(raw)}">Insert</button></div>`;
    });
    out = out.replace(/`([^`]+)`/g, "<code>$1</code>");
    out = out.replace(/\*\*([^*]+)\*\*/g, "<strong>$1</strong>");
    out = out.replace(/\n/g, "<br>");
    return out;
  }

  newChat() {
    this.history = [];
    this.currentResponse = "";
    this.renderHistory();
    this.setStatus("New chat");
  }

  stop() {
    try { this.abortController?.abort(); } catch (_) {}
    this.setBusy(false);
    this.setStatus("Stopped");
  }

  setBusy(busy) {
    const send = this.container?.querySelector("#gca-send");
    const stop = this.container?.querySelector("#gca-stop");
    if (send) send.classList.toggle("hidden", busy);
    if (stop) stop.classList.toggle("hidden", !busy);
  }

  setStatus(text, error = false) {
    const el = this.container?.querySelector("#gca-status");
    if (el) { el.textContent = text; el.style.color = error ? "#ff7b7b" : ""; }
  }

  renderAttachments() {
    const el = this.container?.querySelector("#gca-attachments");
    if (!el) return;
    const names = this.fileParts.map(p => p.__name).concat(this.imageParts.map(p => p.__name));
    el.innerHTML = names.map((n, i) => `<span class="gca-chip">${this.esc(n)}</span>`).join("");
  }

  async pickFile() {
    try {
      const browser = acode.require("fileBrowser");
      const selected = await browser({ mode: "file", info: "Choose a file to send to Gemini" });
      if (!selected?.url) return;
      const fs = acode.require("fs");
      const op = fsOperation(selected.url);
      const text = await op.readFile();
      this.fileParts.push({ text: `\nAttached file (${selected.name}):\n\`\`\`\n${String(text)}\n\`\`\``, __name: selected.name });
      this.renderAttachments();
    } catch (e) { this.setStatus(`File error: ${e.message || e}`, true); }
  }

  async pickImage() {
    const input = document.createElement("input");
    input.type = "file"; input.accept = "image/*"; input.multiple = true; input.style.display = "none";
    document.body.appendChild(input);
    input.onchange = async () => {
      for (const file of [...input.files]) {
        const dataUrl = await new Promise((resolve, reject) => { const r = new FileReader(); r.onload = () => resolve(r.result); r.onerror = reject; r.readAsDataURL(file); });
        const [meta, data] = String(dataUrl).split(",");
        this.imageParts.push({ inlineData: { mimeType: file.type || meta.match(/data:([^;]+)/)?.[1] || "image/jpeg", data }, __name: file.name });
      }
      this.renderAttachments();
      input.remove();
    };
    input.click();
  }

  toggleVoice() {
    const Speech = window.SpeechRecognition || window.webkitSpeechRecognition;
    if (!Speech) return this.setStatus("Voice input is not available in this Acode/WebView build.", true);
    if (this.recognition) { this.recognition.stop(); this.recognition = null; this.setStatus("Ready"); return; }
    const input = this.container?.querySelector("#gca-input");
    const r = new Speech(); r.lang = navigator.language || "en-US"; r.interimResults = true; r.continuous = false;
    r.onstart = () => this.setStatus("Listening…");
    r.onresult = (e) => { input.value = [...e.results].map(x => x[0].transcript).join(" "); };
    r.onerror = (e) => this.setStatus(`Voice error: ${e.error}`, true);
    r.onend = () => { this.recognition = null; this.setStatus("Ready"); };
    this.recognition = r; r.start();
  }

  showSettings() {
    if (!this.container) return;
    const old = this.container.innerHTML;
    this.container.innerHTML = `<style>${this.css()}</style><div class="gca gca-settings-panel">
      <div class="gca-head"><strong>Gemini Settings</strong><button id="gca-back">←</button></div>
      <label>Gemini API key</label><input id="s-key" type="password" placeholder="AIza…">
      <label>Model</label><input id="s-model" value="${this.attr(this.model)}">
      <label>Maximum output tokens</label><input id="s-tokens" type="number" min="256" max="65536" value="${this.maxTokens}">
      <label>Temperature</label><input id="s-temp" type="number" min="0" max="2" step="0.1" value="${this.temperature}">
      <label>System prompt</label><textarea id="s-system">${this.esc(this.systemPrompt)}</textarea>
      <div class="gca-row"><button id="s-save">Save</button><button id="s-clear">Clear API key</button></div>
      <p class="muted">The API key is stored using Acode's plugin secret storage when available.</p>
    </div>`;
    const keyInput = this.container.querySelector("#s-key");
    this.getKey().then(k => { keyInput.value = k; });
    this.container.querySelector("#gca-back").onclick = () => { this.renderShell(); };
    this.container.querySelector("#s-save").onclick = async () => {
      const key = keyInput.value.trim();
      if (this.ctx?.setSecret && key) await this.ctx.setSecret("gemini_api_key", key);
      this.model = this.container.querySelector("#s-model").value.trim() || DEFAULT_MODEL;
      this.maxTokens = Number(this.container.querySelector("#s-tokens").value) || DEFAULT_MAX_TOKENS;
      this.temperature = Number(this.container.querySelector("#s-temp").value) || 0.2;
      this.systemPrompt = this.container.querySelector("#s-system").value || DEFAULT_SYSTEM;
      this.savePref("model", this.model); this.savePref("maxTokens", this.maxTokens); this.savePref("temperature", this.temperature); this.savePref("systemPrompt", this.systemPrompt);
      this.renderShell();
      this.setStatus("Saved");
    };
    this.container.querySelector("#s-clear").onclick = async () => { if (this.ctx?.deleteSecret) await this.ctx.deleteSecret("gemini_api_key"); keyInput.value = ""; this.setStatus("API key cleared"); };
  }

  esc(s) { return String(s ?? "").replace(/&/g,"&amp;").replace(/</g,"&lt;").replace(/>/g,"&gt;").replace(/"/g,"&quot;").replace(/'/g,"&#39;"); }
  unesc(s) { const t = document.createElement("textarea"); t.innerHTML = s; return t.value; }
  attr(s) { return this.esc(String(s ?? "")).replace(/\n/g,"&#10;"); }

  destroy() {
    try { this.abortController?.abort(); } catch (_) {}
    try { this.recognition?.stop(); } catch (_) {}
    try { this.commands.removeCommand("gemini-code-assistant"); } catch (_) {}
    try { this.commands.removeCommand("gemini-ask-selection"); } catch (_) {}
    try { this.commands.removeCommand("gemini-fix-selection"); } catch (_) {}
    try { this.commands.removeCommand("gemini-explain-selection"); } catch (_) {}
    try { this.commands.removeCommand("gemini-refactor-selection"); } catch (_) {}
    try { this.commands.removeCommand("gemini-review-file"); } catch (_) {}
    try { this.sidebar?.remove(APP_ID); } catch (_) {}
  }
}

function fsOperation(url) {
  try { return acode.fsOperation(url); } catch (_) {
    const fs = acode.require("fs");
    if (typeof fs?.operation === "function") return fs.operation(url);
    throw new Error("Acode filesystem API is unavailable");
  }
}

if (window.acode) {
  const plugin = new GeminiCodeAssistant();
  acode.setPluginInit(PLUGIN_ID, async (baseUrl, $page, options) => {
    await plugin.init($page, options.cacheFile, options.cacheFileUrl, options.firstInit, options.ctx);
  }, {
    list: [
      { key: "model", text: "Default model", info: "Gemini model used by the assistant.", value: DEFAULT_MODEL, prompt: "Gemini model" },
      { key: "maxTokens", text: "Maximum output tokens", value: DEFAULT_MAX_TOKENS, prompt: "Maximum output tokens", promptType: "number" },
      { key: "temperature", text: "Temperature", value: 0.2, prompt: "Temperature (0–2)", promptType: "number" },
      { key: "attachActive", text: "Attach active file context", checkbox: true, value: true },
      { key: "systemPrompt", text: "System prompt", value: DEFAULT_SYSTEM, prompt: "System prompt" }
    ],
    cb: (key, value) => plugin.savePref(key, value)
  });
  acode.setPluginUnmount(PLUGIN_ID, () => plugin.destroy());
}
