# Gemini Code Assistant for Acode

A lightweight, Android-friendly Gemini coding assistant built as an Acode plugin.

## Features

- Native Acode sidebar app
- Gemini chat with conversation context
- Streaming responses through Gemini's `streamGenerateContent` API
- Current-file context
- Selected-code context
- Explain / Fix / Refactor / Review commands
- Insert or replace editor text
- Copy generated code blocks
- Image input
- File input
- Optional voice input when supported by the Acode WebView
- Multiple Gemini models (loads available models when an API key is configured)
- Custom system prompt
- Maximum output token and temperature controls
- Encrypted Acode plugin secret storage for the API key when available
- No backend, database, or external service required beyond Gemini

## Installation

1. Build/download the plugin ZIP.
2. In Acode open Extensions/Plugins.
3. Tap `+` → `LOCAL`.
4. Select the ZIP.
5. Open the Gemini AI sidebar app.
6. Open its settings and enter your own Gemini API key.

## Notes

The plugin talks directly from Acode to Google's Gemini API. Your API key is not included in the plugin. Use your own key and review Google's current Gemini API pricing/limits before relying on it heavily.
